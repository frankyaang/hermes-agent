# 莎士比亚 T90 样例输入清单

此目录只保留脱敏样例说明，不包含原始业务附件。

本地验收使用过的原始文件为：

- `T系列用户分析.docx`
- `莎士比亚 量价渠分布 - 变更前.xlsx`
- `莎士比亚 量价渠分布 - 变更后.xlsx`

如需复跑，请把同类文件放入一个输入目录，并新增 `change_brief.json`：

```json
{
  "change_name": "莎士比亚 T90 中国区新增中配版",
  "target_region": "中国",
  "focus_change_keywords": ["中配"],
  "competitor_price": 3598,
  "decision_constraints": [
    "价格使用国补后口径",
    "只归因新增中配相关影响",
    "5W2H 不生成营销侧内容"
  ]
}
```
